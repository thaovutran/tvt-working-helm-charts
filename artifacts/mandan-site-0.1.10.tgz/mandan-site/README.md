# ManDan TinyWebsite

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://github.com/kubernetes/dashboard/blob/master/LICENSE)

## TL;DR

```console
# Add mandan-site repository
helm repo add mandan-site https://thawtran.github.io/my-charts

# Deploy a Helm Release named "tinyweb" using the mandan-site chart
helm upgrade --install tinyweb mandan-site/mandan-site --create-namespace --namespace mandan-web-ns
```

# Pre-requisite
This chart requires the `ingress-nginx` installed in your Kubernetes cluster if the value `{{.Values.ingress.enabled }}` is set.

The `mandandb.k8s.local` and `mandanweb.k8s.local` need to be set in the `/etc/hosts` file.
```console
cat /etc/hosts
127.0.0.1       mandandb.k8s.local
127.0.0.1       mandanweb.k8s.local
```

# Introduction

This chart create a **TinyWebsite** and **MongoDB** as well as **MongoExpress** deployments on a [Kubernetes](https://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

<img src="https://raw.githubusercontent.com/thawtran/my-charts/master/photos/manucian.png" alt="Manucian" width="50%">
<img src="https://raw.githubusercontent.com/thawtran/my-charts/master/photos/mongoexp.png" alt="MongoExp" width="50%">

## Installing the Chart

To install the [Chart](https://helm.sh/docs/intro/using_helm/#three-big-concepts) with the [Release](https://helm.sh/docs/intro/using_helm/#three-big-concepts) name `tinyweb` in the namespace `mandan-web-ns`:

```console
helm repo add mandan-site https://thawtran.github.io/my-charts
helm upgrade --install tinyweb mandan-site/mandan-site --create-namespace --namespace mandan-web-ns
```

The command deploys **ManDan TinyWebsite** on the Kubernetes cluster in the `mandan-web-ns` namespace with default
configuration.
The [configuration](#configuration) section lists the parameters that can be configured during installation.

## Uninstalling the Chart

To uninstall/delete the `tinyweb` deployment:

```console
helm delete tinyweb --namespace mandan-web-ns
kubectl delete ns mandan-web-ns
```

The command removes all the **ManDan TinyWebsite** components associated with the chart and deletes the release.


## Access

**If ingress is enabled:**
  - Access Mongo Express: `http://mandandb.k8s.local`
  - Access ManDan website: `http://mandandb.k8s.local`
